from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import re
from werkzeug.security import generate_password_hash, check_password_hash
from math import pow
import os

app = Flask(__name__)
# read database url and secret key from environment (production-ready)
# Prefer an absolute sqlite path to avoid "unable to open database file" on Windows
db_url = os.environ.get('DATABASE_URL')
if not db_url:
    db_file = os.path.join(app.root_path, 'instance', 'database.db')
    # convert backslashes to forward slashes for sqlite URI
    db_url = 'sqlite:///' + db_file.replace('\\', '/')
app.config['SQLALCHEMY_DATABASE_URI'] = db_url
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = os.environ.get('SECRET_KEY', 'chave_secreta_projeto_crm_dev')

db = SQLAlchemy(app)

# ================= MODELS ==================

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), nullable=False)





class Proposta(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    cliente = db.Column(db.String(200), nullable=False)
    cpf = db.Column(db.String(20))
    nb = db.Column(db.String(80))
    tipo_beneficio = db.Column(db.String(40))
    consultor = db.Column(db.String(80), nullable=False)
    tipo_produto = db.Column(db.String(50), nullable=False)
    banco = db.Column(db.String(120))
    banco_id = db.Column(db.Integer, db.ForeignKey('banco.id'))
    valor_solicitado = db.Column(db.Float, nullable=False)
    prazo = db.Column(db.Integer, nullable=False)
    parcela_calculada = db.Column(db.Float)
    status = db.Column(db.String(30), default='Criada')
    data_criacao = db.Column(db.DateTime, default=datetime.utcnow)
    renda = db.Column(db.Float)
    parcela_atual = db.Column(db.Float)
    taxa = db.Column(db.Float)
    banco_atual = db.Column(db.String(120))
    margem_disponivel = db.Column(db.Float)


class HistoricoProposta(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    proposta_id = db.Column(db.Integer, db.ForeignKey('proposta.id'), nullable=False)
    acao = db.Column(db.String(80), nullable=False)
    usuario = db.Column(db.String(80), nullable=False)
    data = db.Column(db.DateTime, default=datetime.utcnow)
    observacao = db.Column(db.String(500))

    proposta = db.relationship('Proposta', backref=db.backref('historico', lazy=True))


class Banco(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(120), unique=True, nullable=False)
    taxa_padrao = db.Column(db.Float)
    prazo_maximo = db.Column(db.Integer)
    propostas = db.relationship('Proposta', backref='banco_obj', lazy=True)


# ============ INIT DATABASE =============

with app.app_context():
    # ensure instance folder exists for sqlite fallback
    try:
        os.makedirs(os.path.join(app.root_path, 'instance'), exist_ok=True)
    except Exception:
        pass
    db.create_all()
    # Seed users (avoid duplicates)
    seed_users = [
        # Masters
        {'username': '@LLucas26', 'password': '@LCRM026', 'role': 'master'},
        {'username': '@LSolas26', 'password': '@SCRM026', 'role': 'master'},
        {'username': '@LLuan26',  'password': '@LCRM026', 'role': 'master'},
        {'username': '@LTriete26','password': '@TCRM026', 'role': 'master'},
        # Consultores
        {'username': '@LCaio26',  'password': '@CCRM026', 'role': 'consultor'},
        {'username': '@LJhon26',  'password': '@JCRM026', 'role': 'consultor'},
        {'username': '@LDavi26',  'password': '@DCRM026', 'role': 'consultor'},
        # no demo users kept
    ]

    for u in seed_users:
        if not User.query.filter_by(username=u['username']).first():
            db.session.add(User(username=u['username'],
                                password=generate_password_hash(u['password']),
                                role=u['role']))

    db.session.commit()

    # Seed bancos (avoid duplicates)
    seed_bancos = [
        {'nome': 'Caixa', 'taxa_padrao': 2.0, 'prazo_maximo': 96},
        {'nome': 'BB', 'taxa_padrao': 2.5, 'prazo_maximo': 96},
        {'nome': 'Bradesco', 'taxa_padrao': 3.0, 'prazo_maximo': 96},
        {'nome': 'Itaú', 'taxa_padrao': 2.8, 'prazo_maximo': 96},
        {'nome': 'Santander', 'taxa_padrao': 3.2, 'prazo_maximo': 96},
        {'nome': 'BMG', 'taxa_padrao': 4.0, 'prazo_maximo': 96},
        {'nome': 'Pan', 'taxa_padrao': 4.5, 'prazo_maximo': 84},
        {'nome': 'C6', 'taxa_padrao': 3.5, 'prazo_maximo': 96},
        {'nome': 'Daycoval', 'taxa_padrao': 4.2, 'prazo_maximo': 96},
    ]
    for b in seed_bancos:
        if not Banco.query.filter_by(nome=b['nome']).first():
            db.session.add(Banco(nome=b['nome'], taxa_padrao=b['taxa_padrao'], prazo_maximo=b['prazo_maximo']))
    db.session.commit()


# ================= FUNÇÕES DE CÁLCULO ==================

def calc_parcela_emprestimo(valor, prazo, taxa_mensal):
    if prazo <= 0:
        return 0
    if not taxa_mensal or taxa_mensal == 0:
        return round(valor / prazo, 2)
    i = taxa_mensal
    parcela = valor * i / (1 - pow(1 + i, -prazo))
    return round(parcela, 2)


def calc_margem_consignavel(renda, comprometimento_atual=0.0, percentual=0.3):
    if not renda:
        return 0.0
    margem = renda * percentual - (comprometimento_atual or 0.0)
    return round(max(0.0, margem), 2)


def calc_portabilidade(valor_solicitado, prazo, taxa_mensal, parcela_atual):
    parcela = calc_parcela_emprestimo(valor_solicitado, prazo, taxa_mensal)
    vantagem = parcela_atual is not None and parcela < parcela_atual
    return parcela, vantagem


def validate_cpf(cpf: str) -> bool:
    # basic CPF validation: remove non-digits and check length and checksum
    if not cpf:
        return False
    s = re.sub(r'\D', '', cpf)
    if len(s) != 11:
        return False
    # checksum validation
    def digits_of(n):
        return list(map(int, n))
    digits = digits_of(s)
    for t in [9, 10]:
        total = sum((digits[i] * (t+1 - i) for i in range(0, t)))
        check = (total * 10) % 11
        if check == 10:
            check = 0
        if check != digits[t]:
            return False
    return True


# ================= ROTAS ==================

@app.route("/")
def home():
    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        usuario = request.form.get("usuario")
        senha = request.form.get("senha")

        user = User.query.filter_by(username=usuario).first()

        if user and check_password_hash(user.password, senha):
            session["usuario"] = user.username
            session["tipo"] = user.role

            return redirect(url_for("painel_consultor" if user.role == "consultor" else "painel_master"))

        flash("Login inválido", "danger")

    return render_template("login.html")


@app.route("/painel_consultor")
def painel_consultor():
    if session.get("tipo") != "consultor":
        return redirect(url_for("login"))
    return render_template("painel_consultor.html")


@app.route("/painel_master")
def painel_master():
    if session.get("tipo") != "master":
        return redirect(url_for("login"))
    return render_template("painel_master.html")


@app.route('/proposta/criar', methods=['GET', 'POST'])
def criar_proposta():
    if session.get('tipo') != 'consultor':
        return redirect(url_for('login'))
    bancos = Banco.query.order_by(Banco.nome).all()

    if request.method == 'POST':
        cliente = request.form.get('cliente')
        cpf = request.form.get('cpf')
        nb = request.form.get('nb')
        tipo_beneficio = request.form.get('tipo_beneficio')
        tipo = request.form.get('tipo_produto')
        banco_id = request.form.get('banco_id')
        banco_atual = request.form.get('banco_atual')
        try:
            valor = float(request.form.get('valor_solicitado') or 0)
        except ValueError:
            flash('Valor solicitado inválido', 'danger')
            return render_template('criar_proposta.html', bancos=bancos)

        try:
            prazo = int(request.form.get('prazo') or 96)
        except ValueError:
            prazo = 96

        try:
            renda = float(request.form.get('renda') or 0)
        except ValueError:
            renda = 0

        try:
            parcela_atual_raw = request.form.get('parcela_atual')
            parcela_atual = float(parcela_atual_raw) if parcela_atual_raw not in (None, '') else None
        except ValueError:
            flash('Parcela atual inválida', 'danger')
            return render_template('criar_proposta.html', bancos=bancos)

        # taxa is provided as percentage (e.g., 2 means 2%)
        try:
            taxa_input = float(request.form.get('taxa') or 0)
            taxa = taxa_input / 100.0 if taxa_input > 1 else taxa_input
        except ValueError:
            flash('Taxa inválida', 'danger')
            return render_template('criar_proposta.html', bancos=bancos)

        try:
            margem_disponivel = float(request.form.get('margem_disponivel') or 0)
        except ValueError:
            margem_disponivel = 0

        # Validations
        if not cliente or len(cliente.strip()) < 3:
            flash('Nome do cliente é obrigatório', 'danger')
            return render_template('criar_proposta.html', bancos=bancos)

        if not validate_cpf(cpf):
            flash('CPF inválido. Informe 11 dígitos.', 'danger')
            return render_template('criar_proposta.html', bancos=bancos)

        if tipo == 'portabilidade':
            if parcela_atual is None or not banco_atual:
                flash('Para portabilidade, informe parcela atual e banco atual', 'danger')
                return render_template('criar_proposta.html', bancos=bancos)

        if tipo == 'margem':
            if not renda or renda <= 0:
                flash('Para margem, informe a renda', 'danger')
                return render_template('criar_proposta.html', bancos=bancos)

        # cálculo da parcela
        parcela = 0
        if tipo == 'financiamento':
            parcela = calc_parcela_emprestimo(valor, prazo, taxa)
        elif tipo == 'portabilidade':
            parcela, vantagem = calc_portabilidade(valor, prazo, taxa, parcela_atual)
            if not vantagem:
                flash('Portabilidade sem vantagem financeira (nova parcela não é menor)', 'danger')
                return render_template('criar_proposta.html', bancos=bancos)
        elif tipo == 'margem':
            parcela = calc_margem_consignavel(renda, parcela_atual)

        # bloquear se parcela > margem disponível
        if margem_disponivel and parcela > margem_disponivel:
            flash(f'Parcela R$ {parcela:.2f} excede margem disponível R$ {margem_disponivel:.2f}', 'danger')
            return render_template('criar_proposta.html', bancos=bancos)

        banco_obj = None
        if banco_id:
            banco_obj = Banco.query.get(int(banco_id))

        p = Proposta(cliente=cliente, cpf=cpf, nb=nb, tipo_beneficio=tipo_beneficio, consultor=session['usuario'],
                     tipo_produto=tipo, banco=banco_obj.nome if banco_obj else request.form.get('banco'), banco_id=(banco_obj.id if banco_obj else None),
                     valor_solicitado=valor, prazo=prazo, parcela_calculada=parcela, renda=renda,
                     parcela_atual=parcela_atual, taxa=taxa, banco_atual=banco_atual, margem_disponivel=margem_disponivel)

        db.session.add(p)
        db.session.commit()

        db.session.add(HistoricoProposta(proposta_id=p.id, acao='Criada', usuario=session['usuario']))
        db.session.commit()

        flash('Proposta criada com sucesso', 'success')
        return redirect(url_for('minhas_propostas'))

    return render_template('criar_proposta.html', bancos=Banco.query.order_by(Banco.nome).all())


@app.route('/minhas_propostas')
def minhas_propostas():
    if session.get('tipo') != 'consultor':
        return redirect(url_for('login'))

    propostas = Proposta.query.filter_by(consultor=session['usuario']).order_by(Proposta.data_criacao.desc()).all()
    return render_template('minhas_propostas.html', propostas=propostas)



@app.route('/propostas')
def listar_propostas():
    if session.get('tipo') != 'master':
        return redirect(url_for('login'))

    q = request.args.get('q')
    if q:
        propostas = Proposta.query.filter((Proposta.cliente.contains(q)) | (Proposta.consultor.contains(q))).order_by(Proposta.data_criacao.desc()).all()
    else:
        propostas = Proposta.query.order_by(Proposta.data_criacao.desc()).all()

    return render_template('propostas_list.html', propostas=propostas)


@app.route('/proposta/<int:pid>/aprovar', methods=['POST'])
def aprovar_proposta(pid):
    if session.get('tipo') != 'master':
        return redirect(url_for('login'))

    p = Proposta.query.get_or_404(pid)
    obs = request.form.get('observacao')
    p.status = 'Aprovada'
    db.session.add(p)
    h = HistoricoProposta(proposta_id=p.id, acao='Aprovada', usuario=session['usuario'], observacao=obs)
    db.session.add(h)
    db.session.commit()
    flash(f'Proposta #{p.id} aprovada!', 'success')
    return redirect(request.referrer or url_for('listar_propostas'))


@app.route('/proposta/<int:pid>/reprovar', methods=['POST'])
def reprovar_proposta(pid):
    if session.get('tipo') != 'master':
        return redirect(url_for('login'))

    p = Proposta.query.get_or_404(pid)
    obs = request.form.get('observacao')
    p.status = 'Reprovada'
    db.session.add(p)
    h = HistoricoProposta(proposta_id=p.id, acao='Reprovada', usuario=session['usuario'], observacao=obs)
    db.session.add(h)
    db.session.commit()
    flash(f'Proposta #{p.id} reprovada!', 'success')
    return redirect(request.referrer or url_for('listar_propostas'))


@app.route('/proposta/<int:pid>/historico')
def proposta_historico(pid):
    if session.get('tipo') not in ('master', 'consultor'):
        return redirect(url_for('login'))
    p = Proposta.query.get_or_404(pid)
    if session.get('tipo') == 'consultor' and p.consultor != session.get('usuario'):
        return redirect(url_for('painel_consultor'))
    historico = HistoricoProposta.query.filter_by(proposta_id=p.id).order_by(HistoricoProposta.data.desc()).all()
    return render_template('proposta_historico.html', proposta=p, historico=historico)


@app.route('/digitacao')
def digitacao():
    # permitir acesso rápido para desenvolvimento: /digitacao?dev=1
    from flask import request
    if request.args.get('dev') == '1':
        return render_template('digitacao.html')
    # requer autenticação mínima; redireciona para login se não estiver logado
    if not session.get('tipo'):
        return redirect(url_for('login'))
    return render_template('digitacao.html')


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


if __name__ == "__main__":
    app.run(debug=True)
