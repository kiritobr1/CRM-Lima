CRM LIMA

Aplicação Flask para gestão de propostas (versão simplificada).

OBS: O módulo de Vouchers foi removido deste repositório — o app foca em propostas e esteira.

## Executar localmente (desenvolvimento)

1. Criar e ativar ambiente virtual (Windows PowerShell):

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

2. Instalar dependências:

```powershell
pip install -r requirements.txt
```

3. Variáveis de ambiente úteis (opcional para local):

```powershell
$env:SECRET_KEY = 'alguma_chave_local'
$env:DATABASE_URL = 'sqlite:///instance/database.db'
```

4. Rodar a aplicação:

```powershell
python app.py
```

Acesse em `http://127.0.0.1:5000`.

## Usuários seedados

Os usuários já criados no banco (seed):

- Masters:
  - @LLucas26 / @LCRM026
  - @LSolas26 / @SCRM026
  - @LLuan26  / @LCRM026
  - @LTriete26/ @TCRM026
- Consultores:
  - @LCaio26 / @CCRM026
  - @LJhon26 / @JCRM026
  - @LDavi26 / @DCRM026

> As senhas acima são usadas apenas para ambiente de desenvolvimento/interno. Em produção, gere senhas seguras e gerencie via sistema de identidade.

## Como colocar em produção (resumo)

Opções recomendadas:
- PaaS (Render, Railway, Fly, Heroku) — deploy via Git, TLS automático. Menos overhead operacional.
- VPS + Docker / systemd + nginx + certbot — mais controle, recomendado para produção estável.

Passos principais (VPS com systemd/nginx):
1. Provisionar servidor Ubuntu 22.04
2. Criar usuário para a app e clonar o repositório
3. Criar virtualenv e instalar dependências (`pip install -r requirements.txt`)
4. Configurar banco de produção (PostgreSQL recomendado)
5. Definir variáveis de ambiente: `DATABASE_URL`, `SECRET_KEY`
6. Executar com `gunicorn` e gerenciar via `systemd`
7. Configurar `nginx` como reverse-proxy e ativar TLS com `certbot`

Exemplo rápido para variáveis de ambiente (systemd EnvironmentFile `/etc/crmapp.env`):

```
FLASK_ENV=production
SECRET_KEY=uma_chave_secreta_long_aqui
DATABASE_URL=postgresql://crmuser:senha@localhost/crmdb
```

## Docker (opção)
Crie um `Dockerfile` e `docker-compose.yml` para facilitar deploy/containerização. Use `postgres` como serviço para produção.

## Observações de segurança
- NÃO rode com `debug=True` em produção.
- Mantenha `SECRET_KEY` e credenciais fora do controle de versão.
- Use HTTPS sempre.

---

Se quiser, eu gero automaticamente exemplos de `systemd`/`nginx`/`Dockerfile` e `docker-compose.yml` adaptados ao seu projeto. Diga qual prefere que eu gere e eu adiciono ao repositório.
