import traceback
import sys
try:
    import app
    print('app imported successfully')
    print('App attributes:', [a for a in dir(app) if a.startswith('db') or a.startswith('User')][:20])
except Exception:
    traceback.print_exc()
    sys.exit(1)
