import sys
sys.path.insert(0, r'D:\CRM LIMA\Projeto CRM')
from app import db, User, Voucher, VoucherHistorico, app

with app.app_context():
    # delete voucher historico first
    try:
        VoucherHistorico.query.delete()
        db.session.commit()
    except Exception as e:
        print('VoucherHistorico deletion skipped or error:', e)

    try:
        Voucher.query.delete()
        db.session.commit()
    except Exception as e:
        print('Voucher deletion skipped or error:', e)

    # delete demo users 'consultor1' and 'master' if present
    try:
        User.query.filter(User.username.in_(['consultor1', 'master'])).delete(synchronize_session=False)
        db.session.commit()
    except Exception as e:
        print('User deletion skipped or error:', e)

    print('Cleanup complete')
